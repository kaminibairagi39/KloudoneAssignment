
import React, { useContext, useState } from 'react'
import ChartCard from '../components/Chart/ChartCard'
import { Doughnut, Line, Bar } from 'react-chartjs-2'
import ChartLegend from '../components/Chart/ChartLegend'
import {
  doughnutOptions,
  lineOptions,
  barOptions,
  doughnutLegends,
  lineLegends,
  barLegends,
} from '../utils/demo/chartsData'
import {
  SearchIcon,
  MoonIcon,
  SunIcon,
  BellIcon,
  MenuIcon,
  OutlinePersonIcon,
  OutlineCogIcon,
  OutlineLogoutIcon,
} from '../icons'
import { Avatar, Badge, Input, Dropdown, DropdownItem, WindmillContext } from '@windmill/react-ui'
import { SidebarContext } from '../context/SidebarContext'

function Charts() {
  const { mode, toggleMode } = useContext(WindmillContext)
  const { toggleSidebar } = useContext(SidebarContext)
  return (
    <>
      <a
        className="flex items-center justify-between pb-4 text-sm font-semibold text-gray-500"
        href=""
      >
        <div className="flex items-center">
          {/* <span>Star this project on GitHub</span> */}
          
      <h1 className="my-4 text-2xl font-semibold text-gray-700 dark:text-gray-200">Dashboard</h1>
    
        </div>
        <span>
          <button
            className="rounded-md focus:outline-none focus:shadow-outline-purple"
            onClick={toggleMode}
            aria-label="Toggle color mode"
          >
            {mode === 'dark' ? (
               <div className="my-6 flex items-center">
               <MoonIcon className="w-5 h-5" aria-hidden="true" />
               <span>Night Mode</span>
             </div>
            ) : (
              <div className="my-6 flex items-center">
              <SunIcon className="w-5 h-5" aria-hidden="true" />
              <span>Day Mode</span>
            </div>
      
              )}
          </button>
        </span>
      </a>
      <div className="grid gap-6 mb-8 md:grid-cols-2">
        <ChartCard title="Search Activity">
          <Bar {...barOptions} />
          <ChartLegend legends={barLegends} />
        </ChartCard>

        <ChartCard title="Sales Distribution">
          <Doughnut {...doughnutOptions} />
          <ChartLegend legends={doughnutLegends} />
        </ChartCard>

        <ChartCard title="Sales Activity">
          <Line {...lineOptions} />
          <ChartLegend legends={lineLegends} />
        </ChartCard>

      </div>
    </>
  )
}

export default Charts
