/**
 * ⚠ These are used just to render the Sidebar!
 * You can include any link here, local or external.
 *
 * If you're looking to actual Router routes, go to
 * `routes/index.js`
 */
const routes = [
  {
    path: '/app/dashboard', // the url
    icon: 'HomeIcon', // the component being exported from icons/index.js
    name: 'Dashboard', // name that appear in Sidebar
  },
  {
    path: '/',
    icon: 'FormsIcon',
    name: 'Users',
  },
  {
    path: '/',
    icon: 'CardsIcon',
    name: 'Locations',
  },
  {
    path: '/',
    icon: 'ChartsIcon',
    name: 'Shops',
  },
  {
    path: '/',
    icon: 'ButtonsIcon',
    name: 'Orders',
  },
  {
    path: '/',
    icon: 'ModalsIcon',
    name: 'Categories',
  },
  {
    path: '/',
    icon: 'TablesIcon',
    name: 'Templates',
  },
  {
    path: '/',
    icon: 'CardsIcon',
    name: 'General Settings',
  },
]

export default routes
